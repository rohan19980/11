﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Data.Linq;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace HolidaySystem
{
    public partial class adminform : Form

    {

        DataClasses1DataContext db;


        List<Employee> employees;
        public adminform()
        {
            InitializeComponent();
          db  = new DataClasses1DataContext();

            employees = new List<Employee>();


           
        }

        private void Btncreate_Click(object sender, EventArgs e)
        {
            groupBoxuser.Visible = true;
            
            btnsave.Visible = true;
            btngoback.Visible = true;
            btnupdate.Visible = true;
            //lblconpass.Visible = true;
            lblpass.Visible = true;
            textBoxpassword.Visible = true;
           // textBoxconfirmpassword.Visible = true;
            //UpdateTextBox();
      
        }
        
      

        private void adminform_Load(object sender, EventArgs e)
        {


           
         
            comboBoxrole.Items.Add("Manager");
            comboBoxrole.Items.Add("Head");
            comboBoxrole.Items.Add("Deputy Head");
            comboBoxrole.Items.Add("Apprentice");
            comboBoxrole.Items.Add("Junior member");
            comboBoxrole.Items.Add("Senior member");

            comboBoxdepartment.Items.Add("Engineering");
            comboBoxdepartment.Items.Add("Plumbing");
            comboBoxdepartment.Items.Add("Roofing");
            comboBoxdepartment.Items.Add("Carpentry");
            comboBoxdepartment.Items.Add("Bricklaying");
            comboBoxdepartment.Items.Add("Office");

            comboBoxstaffid.ValueMember = "staffid";
            comboBoxstaffid.DisplayMember = "username";
            comboBoxstaffid.DataSource = db.staffdetails.ToList<staffdetail>();

            btnsave.Visible = false;
            btnupdate.Visible = false;
            btngoback.Visible = false;

        }

        private void comboBoxdepartment_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void btnsave_Click(object sender, EventArgs e)
        {
           // Employee employee = new Employee(int.Parse(textBoxstaffid.Text), textBoxfirstname.Text, comboBoxrole.SelectedItem.ToString());
           // employees.Add(employee);

            var employ = new staffdetail();
           // employ.staffid= int.Parse(textBoxstaffid.Text);
            employ.role = comboBoxrole.SelectedItem.ToString();
            employ.department = comboBoxdepartment.SelectedItem.ToString();
            employ.firstname = textBoxfirstname.Text;
            employ.lastname = textBoxlastname.Text;
            employ.phone = int.Parse(textBoxphone.Text);
            employ.username = textBoxusername.Text;
            employ.password = textBoxpassword.Text;
            employ.email = textBoxemail.Text;
            employ.joiningdate = datepicker.Value;
            db.staffdetails.InsertOnSubmit(employ);
            db.SubmitChanges();

          

            MessageBox.Show("Employee Details Inserted Successfully");
            groupBoxuser.Visible = false;
            searchgroup.Visible = true;
            btncreate.Visible = true;
            btnupdate.Visible = false;


        }

        private void UpdateTextBox()
        {
            textBoxfirstname.Text = "";
            textBoxlastname.Text = "";
           
            textBoxphone.Text = "";
            textBoxusername.Text = "";
            textBoxpassword.Text = "";
            //textBoxconfirmpassword.Text = "";
            textBoxemail.Text = "";
            


            
        }

        private void Btnsearch_Click(object sender, EventArgs e)
        {
           // MessageBox.Show("you have selected  " + comboBoxstaffid.SelectedValue);
           // lblconpass.Visible = false;
            lblpass.Visible = false;
            textBoxpassword.Visible = false;
           // textBoxconfirmpassword.Visible = false;
            groupBoxuser.Visible = true;
            btnsave.Visible = false;
            btncreate.Visible = false;
    
            btnupdate.Visible = true;
            staffdetail staff =
               db.staffdetails.SingleOrDefault(x => x.staffid == int.Parse(comboBoxstaffid.SelectedValue.ToString()));
            textBoxfirstname.Text = staff.firstname;
            textBoxlastname.Text = staff.lastname;
            comboBoxrole.SelectedItem = staff.role;
            comboBoxdepartment.SelectedItem = staff.department;
            textBoxphone.Text =staff.phone.ToString();
            textBoxusername.Text = staff.username;
            textBoxemail.Text = staff.email;
            datepicker.Value = staff.joiningdate;

        }

        private void Btngoback_Click(object sender, EventArgs e)
        {
            groupBoxuser.Visible = false;
            searchgroup.Visible = true;
            btncreate.Visible = true;
            btnsave.Visible = false;
            btnupdate.Visible = false;
            
        }

        private void Btndelete_Click(object sender, EventArgs e)
        {

            staffdetail query =
                db.staffdetails.SingleOrDefault(x => x.staffid == int.Parse(comboBoxstaffid.SelectedValue.ToString()));
                
            db.staffdetails.DeleteOnSubmit(query);
            db.SubmitChanges();

            MessageBox.Show("Empoyee Deleted successfully");
        }

        private void Btnupdate_Click(object sender, EventArgs e)
        {

            staffdetail query =
              db.staffdetails.SingleOrDefault(x => x.staffid == int.Parse(comboBoxstaffid.SelectedValue.ToString()));
            //var employ = new staffdetail();
            // employ.staffid= int.Parse(textBoxstaffid.Text);
           query.role = comboBoxrole.SelectedItem.ToString();
           query.department = comboBoxdepartment.SelectedItem.ToString();
            query.firstname = textBoxfirstname.Text;
            query.lastname = textBoxlastname.Text;
            query.phone = int.Parse(textBoxphone.Text);
            query.username = textBoxusername.Text;
           // employ.password = textBoxpassword.Text;
            query.email = textBoxemail.Text;
            query.joiningdate = datepicker.Value;
           
            db.SubmitChanges();
            MessageBox.Show("Changes updated");
        }
    }
}
