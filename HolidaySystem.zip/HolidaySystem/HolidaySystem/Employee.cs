﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HolidaySystem
{
     class Employee
    {

        string firstName;
        string role;
        string department;
        string lastName;
        int phone;
        string userName;
        string password;
        int staffId;
      

        public Employee(int id, string firstname, string r)
        {
            FirstName = firstname;
            Role = r;
            StaffId = id;

        }

        public Employee()
        {

        }

        public string FirstName { get => firstName; set => firstName = value; }
        public string Role { get => role; set => role = value; }
        public int StaffId { get => staffId; set => staffId = value; }
    }
}
