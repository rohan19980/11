﻿namespace HolidaySystem
{
    partial class adminform
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btncreate = new System.Windows.Forms.Button();
            this.btndelete = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.comboBoxstaffid = new System.Windows.Forms.ComboBox();
            this.searchgroup = new System.Windows.Forms.GroupBox();
            this.label12 = new System.Windows.Forms.Label();
            this.btnsearch = new System.Windows.Forms.Button();
            this.groupBoxuser = new System.Windows.Forms.GroupBox();
            this.btnupdate = new System.Windows.Forms.Button();
            this.datepicker = new System.Windows.Forms.DateTimePicker();
            this.label13 = new System.Windows.Forms.Label();
            this.btngoback = new System.Windows.Forms.Button();
            this.textBoxemail = new System.Windows.Forms.TextBox();
            this.textBoxpassword = new System.Windows.Forms.TextBox();
            this.textBoxusername = new System.Windows.Forms.TextBox();
            this.textBoxphone = new System.Windows.Forms.TextBox();
            this.textBoxlastname = new System.Windows.Forms.TextBox();
            this.textBoxfirstname = new System.Windows.Forms.TextBox();
            this.comboBoxdepartment = new System.Windows.Forms.ComboBox();
            this.comboBoxrole = new System.Windows.Forms.ComboBox();
            this.label10 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.lblpass = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.btnsave = new System.Windows.Forms.Button();
            this.searchgroup.SuspendLayout();
            this.groupBoxuser.SuspendLayout();
            this.SuspendLayout();
            // 
            // btncreate
            // 
            this.btncreate.Location = new System.Drawing.Point(34, 12);
            this.btncreate.Name = "btncreate";
            this.btncreate.Size = new System.Drawing.Size(75, 23);
            this.btncreate.TabIndex = 0;
            this.btncreate.Text = "Create";
            this.btncreate.UseVisualStyleBackColor = true;
            this.btncreate.Click += new System.EventHandler(this.Btncreate_Click);
            // 
            // btndelete
            // 
            this.btndelete.Location = new System.Drawing.Point(21, 59);
            this.btndelete.Name = "btndelete";
            this.btndelete.Size = new System.Drawing.Size(75, 23);
            this.btndelete.TabIndex = 1;
            this.btndelete.Text = "Delete";
            this.btndelete.UseVisualStyleBackColor = true;
            this.btndelete.Click += new System.EventHandler(this.Btndelete_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(298, 9);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(138, 13);
            this.label1.TabIndex = 2;
            this.label1.Text = "Employe Management Form";
            // 
            // comboBoxstaffid
            // 
            this.comboBoxstaffid.FormattingEnabled = true;
            this.comboBoxstaffid.Location = new System.Drawing.Point(131, 19);
            this.comboBoxstaffid.Name = "comboBoxstaffid";
            this.comboBoxstaffid.Size = new System.Drawing.Size(173, 21);
            this.comboBoxstaffid.TabIndex = 3;
            // 
            // searchgroup
            // 
            this.searchgroup.Controls.Add(this.label12);
            this.searchgroup.Controls.Add(this.btnsearch);
            this.searchgroup.Controls.Add(this.comboBoxstaffid);
            this.searchgroup.Controls.Add(this.btndelete);
            this.searchgroup.Location = new System.Drawing.Point(34, 338);
            this.searchgroup.Name = "searchgroup";
            this.searchgroup.Size = new System.Drawing.Size(372, 100);
            this.searchgroup.TabIndex = 6;
            this.searchgroup.TabStop = false;
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(31, 22);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(94, 13);
            this.label12.TabIndex = 6;
            this.label12.Text = "Select Username :";
            // 
            // btnsearch
            // 
            this.btnsearch.Location = new System.Drawing.Point(229, 59);
            this.btnsearch.Name = "btnsearch";
            this.btnsearch.Size = new System.Drawing.Size(75, 23);
            this.btnsearch.TabIndex = 5;
            this.btnsearch.Text = "Search";
            this.btnsearch.UseVisualStyleBackColor = true;
            this.btnsearch.Click += new System.EventHandler(this.Btnsearch_Click);
            // 
            // groupBoxuser
            // 
            this.groupBoxuser.Controls.Add(this.datepicker);
            this.groupBoxuser.Controls.Add(this.label13);
            this.groupBoxuser.Controls.Add(this.textBoxemail);
            this.groupBoxuser.Controls.Add(this.textBoxpassword);
            this.groupBoxuser.Controls.Add(this.textBoxusername);
            this.groupBoxuser.Controls.Add(this.textBoxphone);
            this.groupBoxuser.Controls.Add(this.textBoxlastname);
            this.groupBoxuser.Controls.Add(this.textBoxfirstname);
            this.groupBoxuser.Controls.Add(this.comboBoxdepartment);
            this.groupBoxuser.Controls.Add(this.comboBoxrole);
            this.groupBoxuser.Controls.Add(this.label10);
            this.groupBoxuser.Controls.Add(this.label9);
            this.groupBoxuser.Controls.Add(this.lblpass);
            this.groupBoxuser.Controls.Add(this.label6);
            this.groupBoxuser.Controls.Add(this.label5);
            this.groupBoxuser.Controls.Add(this.label4);
            this.groupBoxuser.Controls.Add(this.label3);
            this.groupBoxuser.Controls.Add(this.label2);
            this.groupBoxuser.Location = new System.Drawing.Point(34, 43);
            this.groupBoxuser.Name = "groupBoxuser";
            this.groupBoxuser.Size = new System.Drawing.Size(741, 234);
            this.groupBoxuser.TabIndex = 7;
            this.groupBoxuser.TabStop = false;
            this.groupBoxuser.Text = "New User Details";
            this.groupBoxuser.Visible = false;
            this.groupBoxuser.Enter += new System.EventHandler(this.Btncreate_Click);
            // 
            // btnupdate
            // 
            this.btnupdate.Location = new System.Drawing.Point(222, 283);
            this.btnupdate.Name = "btnupdate";
            this.btnupdate.Size = new System.Drawing.Size(75, 23);
            this.btnupdate.TabIndex = 24;
            this.btnupdate.Text = "Update";
            this.btnupdate.UseVisualStyleBackColor = true;
            this.btnupdate.Click += new System.EventHandler(this.Btnupdate_Click);
            // 
            // datepicker
            // 
            this.datepicker.CustomFormat = "dd-MM-yyyy";
            this.datepicker.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.datepicker.Location = new System.Drawing.Point(433, 183);
            this.datepicker.Name = "datepicker";
            this.datepicker.Size = new System.Drawing.Size(100, 20);
            this.datepicker.TabIndex = 23;
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(313, 183);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(69, 13);
            this.label13.TabIndex = 22;
            this.label13.Text = "Joining Date:";
            // 
            // btngoback
            // 
            this.btngoback.Location = new System.Drawing.Point(128, 283);
            this.btngoback.Name = "btngoback";
            this.btngoback.Size = new System.Drawing.Size(75, 23);
            this.btngoback.TabIndex = 21;
            this.btngoback.Text = "Go Back";
            this.btngoback.UseVisualStyleBackColor = true;
            this.btngoback.Click += new System.EventHandler(this.Btngoback_Click);
            // 
            // textBoxemail
            // 
            this.textBoxemail.Location = new System.Drawing.Point(433, 151);
            this.textBoxemail.Name = "textBoxemail";
            this.textBoxemail.Size = new System.Drawing.Size(100, 20);
            this.textBoxemail.TabIndex = 19;
            // 
            // textBoxpassword
            // 
            this.textBoxpassword.Location = new System.Drawing.Point(433, 66);
            this.textBoxpassword.Name = "textBoxpassword";
            this.textBoxpassword.Size = new System.Drawing.Size(100, 20);
            this.textBoxpassword.TabIndex = 17;
            // 
            // textBoxusername
            // 
            this.textBoxusername.Location = new System.Drawing.Point(433, 25);
            this.textBoxusername.Name = "textBoxusername";
            this.textBoxusername.Size = new System.Drawing.Size(100, 20);
            this.textBoxusername.TabIndex = 16;
            // 
            // textBoxphone
            // 
            this.textBoxphone.Location = new System.Drawing.Point(113, 195);
            this.textBoxphone.Name = "textBoxphone";
            this.textBoxphone.Size = new System.Drawing.Size(100, 20);
            this.textBoxphone.TabIndex = 15;
            // 
            // textBoxlastname
            // 
            this.textBoxlastname.Location = new System.Drawing.Point(113, 155);
            this.textBoxlastname.Name = "textBoxlastname";
            this.textBoxlastname.Size = new System.Drawing.Size(100, 20);
            this.textBoxlastname.TabIndex = 14;
            // 
            // textBoxfirstname
            // 
            this.textBoxfirstname.Location = new System.Drawing.Point(113, 114);
            this.textBoxfirstname.Name = "textBoxfirstname";
            this.textBoxfirstname.Size = new System.Drawing.Size(100, 20);
            this.textBoxfirstname.TabIndex = 13;
            // 
            // comboBoxdepartment
            // 
            this.comboBoxdepartment.FormattingEnabled = true;
            this.comboBoxdepartment.Location = new System.Drawing.Point(113, 70);
            this.comboBoxdepartment.Name = "comboBoxdepartment";
            this.comboBoxdepartment.Size = new System.Drawing.Size(121, 21);
            this.comboBoxdepartment.TabIndex = 12;
            this.comboBoxdepartment.SelectedIndexChanged += new System.EventHandler(this.comboBoxdepartment_SelectedIndexChanged);
            // 
            // comboBoxrole
            // 
            this.comboBoxrole.FormattingEnabled = true;
            this.comboBoxrole.Location = new System.Drawing.Point(113, 25);
            this.comboBoxrole.Name = "comboBoxrole";
            this.comboBoxrole.Size = new System.Drawing.Size(121, 21);
            this.comboBoxrole.TabIndex = 11;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(20, 198);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(47, 13);
            this.label10.TabIndex = 9;
            this.label10.Text = "Phone : ";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(313, 158);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(39, 13);
            this.label9.TabIndex = 8;
            this.label9.Text = "EMail :";
            // 
            // lblpass
            // 
            this.lblpass.AutoSize = true;
            this.lblpass.Location = new System.Drawing.Point(313, 73);
            this.lblpass.Name = "lblpass";
            this.lblpass.Size = new System.Drawing.Size(59, 13);
            this.lblpass.TabIndex = 6;
            this.lblpass.Text = "Password :";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(313, 33);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(64, 13);
            this.label6.TabIndex = 5;
            this.label6.Text = "Username : ";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(20, 158);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(64, 13);
            this.label5.TabIndex = 4;
            this.label5.Text = "Last Name :";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(20, 114);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(63, 13);
            this.label4.TabIndex = 3;
            this.label4.Text = "First Name :";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(20, 73);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(68, 13);
            this.label3.TabIndex = 2;
            this.label3.Text = "Department :";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(20, 33);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(35, 13);
            this.label2.TabIndex = 1;
            this.label2.Text = "Role :";
            
            // 
            // btnsave
            // 
            this.btnsave.Location = new System.Drawing.Point(34, 283);
            this.btnsave.Name = "btnsave";
            this.btnsave.Size = new System.Drawing.Size(75, 23);
            this.btnsave.TabIndex = 0;
            this.btnsave.Text = "Save";
            this.btnsave.UseVisualStyleBackColor = true;
            this.btnsave.Click += new System.EventHandler(this.btnsave_Click);
            // 
            // adminform
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.btnupdate);
            this.Controls.Add(this.groupBoxuser);
            this.Controls.Add(this.btngoback);
            this.Controls.Add(this.searchgroup);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.btncreate);
            this.Controls.Add(this.btnsave);
            this.Name = "adminform";
            this.Text = "adminform";
            this.Load += new System.EventHandler(this.adminform_Load);
            this.searchgroup.ResumeLayout(false);
            this.searchgroup.PerformLayout();
            this.groupBoxuser.ResumeLayout(false);
            this.groupBoxuser.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btncreate;
        private System.Windows.Forms.Button btndelete;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.ComboBox comboBoxstaffid;
        private System.Windows.Forms.GroupBox searchgroup;
        private System.Windows.Forms.GroupBox groupBoxuser;
        private System.Windows.Forms.Button btnsave;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Button btngoback;
        private System.Windows.Forms.TextBox textBoxemail;
        private System.Windows.Forms.TextBox textBoxpassword;
        private System.Windows.Forms.TextBox textBoxusername;
        private System.Windows.Forms.TextBox textBoxphone;
        private System.Windows.Forms.TextBox textBoxlastname;
        private System.Windows.Forms.TextBox textBoxfirstname;
        private System.Windows.Forms.ComboBox comboBoxdepartment;
        private System.Windows.Forms.ComboBox comboBoxrole;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label lblpass;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Button btnsearch;
        private System.Windows.Forms.DateTimePicker datepicker;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Button btnupdate;
    }
}